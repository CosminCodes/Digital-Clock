# Ceas-digital

Descriere proiect 

Un ceas digital și un calendar cu funcționalitate de alarmă dezvoltat pe microcontrolerul STM32F401 , utilizând RTC DS1307 pentru menținerea timpului. Include o interfață bazată pe un ecran LCD pentru setarea orei, datei și alarmei.
Sistemul oferă o interfață de utilizator bazată pe un ecran LCD, care permite setarea orei, datei și alarmei. Configurările sunt realizate prin intermediul mai multor butoane conectate la microcontroler, folosind un mecanism de întreruperi pentru gestionarea interacțiunilor utilizatorului în timp real.

Printre funcționalitățile sale cheie se numără:

Moduri de ceas configurabile (12h și 24h) cu conversie instantanee între moduri.
Setare și afișare a alarmei și calendarului.
Indicator de alarmă prin intermediul unui LED și buzzer.
Posibilitatea de a opri alarma automat sau manual prin apăsarea unui buton.
Controlul iluminării LCD-ului cu ajutorul unui buton dedicat.


# Bill of Materials (BOM)

| Nr. crt. | Componentă             | Specificații/Descriere                | Cantitate | Observații                                                      |
|----------|------------------------|---------------------------------------|-----------|------------------------------------------------------------------|
| 1        | STM32F401RE Nucleo     | Microcontroller STM32F4 Series       | 1         | Placa principală de control                                     |
| 2        | Modul DS1307 RTC       | Real Time Clock cu comunicație I2C   | 1         | Menține timpul și data chiar și fără alimentare                 |
| 3        | LCD 16x2               | Afișaj LCD cu 16 caractere x 2 rânduri | 1         | Interfață vizuală pentru afișarea orei, datei și alarmei       |
| 4        | Potențiometru 10K      | Reglaj de contrast pentru LCD        | 1         | Conectat la pinul de contrast al LCD-ului                       |
| 5        | Buzzer                 | Buzzer piezoelectric                 | 1         | Indică alarma prin sunet                                        |
| 6        | LED                    | LED standard                         | 1         | Avertizare vizuală pentru alarmă                                |
| 7        | Rezistor 220Ω          | Rezistență pentru LED                | 1         | Limitează curentul pentru LED                                   |
| 8        | Buton Push             | Butoane de configurare               | 4         | Control pentru setarea orei, alarmei, modurilor                 |
| 9        | Fire de conexiune       | Fire de tip male-male, male-female   | Mai multe | Pentru conexiuni între componente                               |
| 10       | Sursa de alimentare    | 5V                                   | 1         | Poate fi sursa de la USB-ul STM32 Nucleo sau altă sursă externă |






# Configurarea Pinilor STM32F401RE pentru Proiect

| Componentă       | Pini utilizați pe STM32F401RE | Funcție                                     |
|------------------|-------------------------------|---------------------------------------------|
| **DS1307 RTC**   | PB6 (SCL), PB7 (SDA)          | I2C pentru comunicație cu RTC               |
| **LCD 16x2**     | PB0, PB1, PA8, PA9, PA10, PA11, PA12, PA15 | GPIO pentru controlul datelor și comenzilor de afișaj |
| **Potențiometru**| Conectat la pinul de contrast al LCD       | Reglaj contrast display                     |
| **Buzzer**       | PA5                           | GPIO pentru activarea/dezactivarea sunetului de alarmă |
| **LED**          | PC13                          | GPIO pentru indicator vizual de alarmă      |
| **Butoane**      | PC0, PC1, PC2, PC3            | GPIO pentru întreruperi externe la apăsarea butoanelor |


# Datasheet și informații despre NUCLEO-F401RE

### Introducere
Placa **NUCLEO-F401RE** este o platformă de dezvoltare STM32 compatibilă cu ecosistemele **Arduino** și **ST Morpho**, fiind destinată prototipurilor rapide și dezvoltării aplicațiilor embedded. Aceasta include un **STM32F401RE MCU** (bazat pe ARM Cortex-M4), un debugger **ST-LINK/V2-1** integrat și suportă o gamă largă de periferice.

---

### Specificații cheie ale plăcii
1. **Microcontroller STM32F401RE**:
   - ARM Cortex-M4 cu FPU, tactat la 84 MHz.
   - Memorie flash: 512 KB.
   - RAM: 96 KB.
   - 12 canale ADC de 12 biți, 6 canale PWM.

2. **Interfață debugger integrată**:
   - **ST-LINK/V2-1** pentru programare și depanare.
   - Mod SWD (Serial Wire Debug) activat implicit.

3. **Conectivitate**:
   - Compatibilitate cu pini **Arduino Uno R3**.
   - Header **ST Morpho** pentru acces la toți pinii MCU.

4. **Alimentare**:
   - Micro-USB, VIN (7-12V), sau 3.3V extern.
   - Protecție la supra-curent.

---

### Diagrama pinilor
Mai jos este prezentată schema pinilor pentru **NUCLEO-F401RE**:

![Schema pinilor NUCLEO-F401RE](https://github.com/user-attachments/assets/24c229c1-264b-467f-bd58-b3101f8f3bb5)


#### Conectorii principali:
- **CN7, CN8 (Morpho)**:
  - Acces la toate pinii perifericelor microcontrollerului (GPIO, ADC, PWM etc.).
- **CN5, CN6 (Arduino Uno R3)**:
  - Layout compatibil Arduino, ideal pentru shield-uri.

#### Pini dedicați:
- **BOOT0**: Selectează modul de pornire (bootloader sau aplicație).
- **SWDIO/SWCLK**: Debug și programare prin SWD.
- **LD2**: LED conectat la PA5 (ideal pentru testare rapidă).
- **Reset**: Buton pentru resetarea microcontrollerului.

---

### Resurse utile
1. **Datasheet oficial STM32F401RE**:
   - [STM32F401RE Datasheet](https://www.st.com/resource/en/datasheet/stm32f401re.pdf)
2. **Manual de utilizare NUCLEO-F401RE**:
   - [User Manual](https://www.st.com/resource/en/user_manual/dm00105823.pdf)
3. **Tool-uri necesare**:
   - [STM32CubeIDE](https://www.st.com/en/development-tools/stm32cubeide.html)
   - [STM32CubeProgrammer](https://www.st.com/en/development-tools/stm32cubeprog.html)

---

### Aplicații practice
- Dezvoltarea și prototiparea sistemelor embedded.
- Controlul motoarelor (PWM).
- Achiziție de date prin ADC.
- Aplicații IoT folosind shield-uri Arduino compatibile.

---

### Concluzie
Placa **NUCLEO-F401RE** este versatilă și ușor de utilizat, fiind potrivită atât pentru începători, cât și pentru profesioniști. Datorită compatibilității cu ecosistemele Arduino și ST Morpho, oferă flexibilitate maximă în proiectarea soluțiilor embedded.


# Compararea Plăcilor de Dezvoltare pentru Ceas Digital cu Alarmă

Pentru proiectul nostru de ceas digital cu alarmă, am ales **STM32F401RE Nucleo** datorită echilibrului între performanță, cost și consumul redus de energie. 

---

## 1. NXP FRDM-K64F Freedom Development Board

- **Microcontroller**: NXP Kinetis K64, bazat pe ARM Cortex-M4
- **Frecvență**: 120 MHz, mai rapidă decât STM32F401RE (84 MHz)
- **Memorie**: 1 MB Flash și 256 KB RAM (comparativ cu 512 KB Flash și 96 KB RAM la STM32F401RE)
- **Conectivitate**:
  - Dispune de **Ethernet** și **USB OTG**, oferind conectivitate extinsă (necesar pentru proiecte IoT sau aplicații complexe).
  - Suportă **I2C**, **SPI** și **UART** - la fel ca STM32F401RE, pentru interfațarea cu periferice precum RTC-ul DS1307.
- **GPIO**: 100 pini GPIO, mult mai mulți decât cei 50 pe STM32F401RE.
- **Preț**: Mai ridicat decât STM32F401RE, datorită specificațiilor și conectivității suplimentare.

### Avantaje
- Procesor mai rapid și memorie extinsă, ceea ce o face ideală pentru aplicații complexe sau rețele de senzori.
- Conectivitatea Ethernet o face potrivită pentru proiecte IoT sau aplicații de monitorizare online.

### Dezavantaje
- Specificațiile și conectivitatea sunt supradimensionate pentru un simplu ceas digital.
- Cost ridicat și consum de energie mai mare comparativ cu STM32F401RE.

![image](https://github.com/user-attachments/assets/11aca1c1-72a9-4871-911d-3bcd3c6a9da5)



---

## 2. Infineon XMC4500 

- **Microcontroller**: Infineon XMC4500, bazat pe ARM Cortex-M4 (același nucleu ca STM32F401RE)
- **Frecvență**: 120 MHz, mai rapidă decât STM32F401RE
- **Memorie**: 1 MB Flash și 160 KB RAM, mai mare decât STM32F401RE
- **Conectivitate**:
  - Include **Ethernet** și **USB**, oferind conectivitate avansată.
  - Suportă **I2C** și **SPI**, potrivit pentru conectarea la RTC-ul DS1307.
- **GPIO**: Peste 70 pini GPIO, comparativ cu cei 50 pe STM32F401RE.
- **Preț**: Semnificativ mai scump decât STM32F401RE, datorită conectivității Ethernet și specificațiilor avansate.

### Avantaje
- Procesor rapid și memorie mare, ideal pentru aplicații industriale complexe.
- Ethernet și USB permit conectivitate extinsă și transfer de date, util pentru aplicații IoT sau sisteme de monitorizare.
- Include funcții specializate precum modul CCU8 (Capture/Compare Unit) și CCU4 pentru controlul motoarelor și aplicații precise de temporizare.
### Dezavantaje
- Resursele sunt supradimensionate pentru un proiect de ceas digital, ceea ce crește inutil complexitatea și costul.
- Consumul de energie este mai mare, iar memoria extinsă este inutilă pentru aplicația de față.
- Disponibilitate mai redusa.
![image](https://github.com/user-attachments/assets/23277cc1-f9a8-499a-8b49-2a2ad23e140d)


---

## 3. STM32F401RE Nucleo

- **Microcontroller**: STM32F401RE, bazat pe ARM Cortex-M4 cu FPU (Floating Point Unit)
- **Frecvență**: 84 MHz, suficientă pentru aplicații embedded cu cerințe medii de performanță
- **Memorie**: 512 KB Flash și 96 KB RAM, suficiente pentru proiectul de ceas digital cu alarmă, fără a adăuga costuri inutile pentru spațiu de stocare extins
- **Conectivitate**:
  - Suportă **I2C**, **SPI**, și **UART** - toate fiind utile pentru conectarea la perifericele necesare (RTC DS1307, LCD, LED, buzzer și butoane).
  - Spre deosebire de alte plăci mai scumpe, nu are Ethernet sau USB OTG, funcționalități care nu sunt necesare pentru acest proiect, permițând astfel o eficiență energetică mai mare.
- **GPIO**: 50 pini GPIO, suficienți pentru aplicația ta fără a adăuga complexitate inutilă.
- **Preț**: Accesibil, oferind un excelent echilibru între cost și performanță, ceea ce îl face ideal pentru proiecte embedded de complexitate medie.

### Avantaje
- **Optimizare pentru consum redus**: STM32F401RE consumă mai puțină energie decât alte plăci mai performante, făcându-l ideal pentru proiecte alimentate continuu.
- **Performanță echilibrată**: Frecvența de 84 MHz și memoria de 96 KB RAM sunt suficiente pentru un ceas digital, asigurând performanța necesară fără a crește costurile.


### Dezavantaje
- **Fără conectivitate Ethernet sau USB**: Spre deosebire de plăcile de la NXP și Infineon, STM32F401RE nu include Ethernet sau USB OTG. Totuși, aceste funcționalități nu sunt necesare pentru un simplu ceas digital cu alarmă.
- **Capacitate de stocare limitată**: 512 KB Flash și 96 KB RAM sunt suficiente pentru proiectul actual, dar ar putea fi insuficiente pentru proiecte mult mai mari sau mai complexe.


![image](https://github.com/user-attachments/assets/758fa8e0-9190-43b5-84d5-a98416f3e23e)






## Concluzie

După această analiză, **STM32F401RE Nucleo** este cea mai potrivită alegere pentru proiectul meu de ceas digital cu alarmă, oferind:

1. **Perifericele necesare** (GPIO, I2C, Timer) pentru integrarea RTC-ului DS1307, a LCD-ului, LED-ului, buzzerului și butoanelor.
2. **Echilibru între performanță și consum de energie**, optim pentru aplicații embedded de complexitate medie.
3. **Cost accesibil**, oferind toate resursele necesare fără specificații inutile.

---

## Tabel Comparativ

| Caracteristică         | STM32F401RE Nucleo           | NXP FRDM-K64F                  | Infineon XMC4500 Relax Kit        |
|------------------------|------------------------------|--------------------------------|-----------------------------------|
| **Microcontroller**    | STM32F401RE (ARM Cortex-M4)  | NXP Kinetis K64 (ARM Cortex-M4) | Infineon XMC4500 (ARM Cortex-M4)  |
| **Frecvență**          | 84 MHz                       | 120 MHz                        | 120 MHz                           |
| **Memorie Flash**      | 512 KB                       | 1 MB                           | 1 MB                              |
| **Memorie RAM**        | 96 KB                        | 256 KB                         | 160 KB                            |
| **Conectivitate**      | I2C, SPI, UART               | I2C, SPI, UART, Ethernet, USB  | I2C, SPI, UART, Ethernet, USB     |
| **GPIO**               | 50 pini                      | 100 pini                       | Peste 70 pini                     |
| **Consum energie**     | Eficient                     | Mai mare                       | Mai mare                          |
| **Cost**               | 80 lei                       | 300 lei                        | 200 lei                           |
| **Aplicații potrivite**| Proiecte embedded generale   | Aplicații complexe, IoT        | Aplicații industriale, IoT        |

---

# Schema logica a proiectului 

![image](https://github.com/user-attachments/assets/2b777af2-8a73-43a0-90c1-039d8f2e3c25)

# Configuratia pinilor
![image](https://github.com/user-attachments/assets/46df3eef-f4ba-4854-adc1-e60320a10c51)


# Schema electrica (KiCad)
![image](https://github.com/user-attachments/assets/867463f6-da73-4862-a482-b446b0b28f49)

# Implementare

## Implementarea Butoanelor

Sistemul este controlat și configurat folosind 4 butoane, fiecare având funcționalități diferite.

<p align="center">
	<p align="center">
	<img src="https://github.com/user-attachments/assets/3c2a556e-9490-492c-a20c-004770c42831" width="80%" height="80%">
</p>


### Buton 1: Buton de Configurare RTC

- Acest buton este utilizat pentru a comuta între diferitele interfețe de utilizator de pe LCD pentru setarea ceasului, calendarului și alarmei.
- După finalizarea setării, butonul revine la interfața principală afișată pe LCD.

### Buton 2: Buton Mod Ceas

#### Funcție Principală
- Comută între modurile de afișare 12h și 24h.

#### Funcție Secundară
- Setează statusul am/pm pentru ceas și alarmă în modul 12h.
- Setează ziua săptămânii.

### Buton 3: Buton Control Alarmă

#### Funcție Principală
- Oprește alarma în timpul declanșării.
- Activează/Dezactivează alarma (alarma nu se declanșează când este dezactivată).

#### Funcție Secundară
- Setează valoarea orei pentru ceas și alarmă.
- Setează data calendarului.

### Buton 4: Control Iluminare LCD

#### Funcție Principală
- Activează/Dezactivează iluminarea LCD-ului.

#### Funcție Secundară
- Setează valoarea minutelor pentru ceas și alarmă.
- Setează luna din calendar.

---

## Implementarea Afișajului LCD

### Interfața Principală

Interfața principală afișează următoarele caracteristici:


<p align="center">
	<img src="https://github.com/user-attachments/assets/c6edfdbc-3d6d-4584-9fb1-4c331e95e147" width="45%" height="45%">
</p>

- Mod ceas care afișează fie **'24h>'** în format 24h sau **'am/pm'** în format 12h.
- Ora în format **'hh:mm:ss'**.
- Calendarul în format **'zi dd/mm'**.
- Indicator pentru activare/dezactivare alarmă, afișat ca **'AL>'** când este activat.

### Interfețe Secundare

#### Setare Ceas

- Această interfață permite utilizatorului să seteze valorile pentru ore și minute.
- Dacă modul ceas este 12h, există opțiunea de a comuta între am/pm.




<p align="center">
    <img src="https://github.com/user-attachments/assets/20b6938f-dfc6-4240-975e-0f92e74cbea9" width="45%">
    <img src="https://github.com/user-attachments/assets/b99ab8fb-1fb3-4cf1-8361-5e9da11076c2" width="45%">
</p>


#### Setare Calendar


- Această interfață permite utilizatorului să seteze ziua, data și săptămâna.

<p align="center">
	<img src="https://github.com/user-attachments/assets/a866e6ab-fcab-4c58-9ede-280404e14080" width="45%" height="45%">
</p>

#### Setare Alarmă


- Această interfață permite utilizatorului să seteze valorile pentru ore și minute.
- Dacă modul ceas este 12h, există opțiunea de a comuta între am/pm.
- Reține valorile setate anterior, permițând utilizatorului să știe exact ora la care este setată alarma.

<p align="center">
    <img src="https://github.com/user-attachments/assets/0bd1bec9-e0f5-43c0-824c-b1201ce6652c" width="45%">
    <img src="https://github.com/user-attachments/assets/91f0409d-392c-47a2-87b3-8c9e2d93840e" width="45%">
</p>








---

## Implementarea Alarmei

- Pentru a indica alarma, un buzzer și un LED sunt integrate, acestea comutând alternativ la fiecare secundă până când alarma este oprită.
- Alarma se va opri automat după 30 de secunde sau poate fi oprită manual folosind butonul dedicat.


# Functionare
## RTC DS1307 pentru menținerea orei

Partea cea mai importantă a unui ceas este menținerea corectă a orei și datei după ce acestea au fost setate de utilizator.

În acest scop, un modul RTC extern DS1307 este integrat cu microcontrolerul folosind protocolul de comunicație **Inter-Integrated Circuit (I2C)**.

### I2C

I2C operează în două moduri:
- **Mod Master** și **Mod Slave**.

În această aplicație:
- STM32F401 acționează ca master.
- DS1307 este slave.

Masterul și slave-ul sunt conectate prin liniile **SDA** și **SCL**, unde:
- **SDA (Serial Data)**: Este utilizat pentru a citi și scrie la adresele necesare ale modulului RTC DS1307.
- **SCL (Serial Clock)**: Transportă semnalul de ceas pe baza căruia are loc transferul de date.

### API-uri HAL I2C

Acest proiect utilizează driverele **STM32 HAL I2C** pentru implementarea I2C. API-urile utilizate sunt următoarele:

| **HAL API**               | **Descriere**                                             |
|---------------------------|-----------------------------------------------------------|
| `HAL_I2C_Mem_Write`       | Scrie 1 byte de date la o adresă specifică a RTC-ului.    |
| `HAL_I2C_Mem_Read`        | Citește 1 byte de date de la o adresă specifică a RTC-ului. |

### Driver RTC

Un driver pentru modulul RTC a fost dezvoltat pentru a expune următoarele API-uri pentru o implementare ușoară:

| **Driver API**            | **Descriere**                                              |
|---------------------------|------------------------------------------------------------|
| `rtc_ds1307_init`          | Inițializează modulul RTC.                                |
| `rtc_ds1307_set_time`      | Setează ora și modulul de ceas (12h/24h).                 |
| `rtc_ds1307_get_time`      | Obține ora curentă și modulul de ceas (12h/24h).          |
| `rtc_ds1307_set_cal`       | Setează ziua, data, luna și anul.                         |
| `rtc_ds1307_get_cal`       | Obține ziua, data, luna și anul curente.                  |

Ora și data curentă sunt preluate din RTC folosind un întrerupător de timer care se declanșează la fiecare secundă.

---

## Integrarea LCD

Un driver pentru afisajul LCD a fost dezvoltat conform fișei tehnice, expunând următoarele API-uri pentru o implementare ușoară:

| **Driver API**            | **Descriere**                                             |
|---------------------------|-----------------------------------------------------------|
| `lcd_init`                | Inițializează afisajul LCD.                               |
| `lcd_send_command`        | Trimite comenzi către LCD conform fișei tehnice.          |
| `lcd_send_data`           | Trimite date către LCD.                                   |
| `lcd_print_string`        | Afișează caractere/șiruri de caractere pe LCD.            |
| `lcd_ctrl_backlight`      | Controlează iluminarea de fundal a LCD-ului.              |

### Comenzi LCD

Următoarele comenzi LCD sunt expuse utilizatorului:

| **LCD Command API**        | **Descriere**                                             |
|----------------------------|-----------------------------------------------------------|
| `lcd_display_clear`         | Curăță afișajul.                                          |
| `lcd_display_return_home`   | Mută afișajul la poziția inițială.                        |
| `lcd_entry_mode_set`        | Setează direcția de mișcare a cursorului și specifică deplasarea afișajului. |
| `lcd_display_on`            | Activează afișajul.                                       |
| `lcd_display_off`           | Dezactivează afișajul.                                    |
| `lcd_display_on_cursor_on`  | Activează cursorul.                                       |
| `lcd_display_on_cursor_off` | Dezactivează cursorul.                                    |
| `lcd_display_on_blink_on`   | Activează funcția de blink.                               |
| `lcd_display_on_blink_off`  | Dezactivează funcția de blink.                            |
| `lcd_function_set`          | Setează lungimea datelor de interfață, numărul de linii de afișaj și fontul caracterelor. |
| `lcd_set_cursor`            | Setează poziția cursorului la o anumită linie și coloană. |

---

## Sistem de buton extern bazat pe întreruperi

Pentru configurarea diferitelor parametri, cum ar fi ceasul, calendarul și alarma, sunt implementate butoane de presiune utilizând **EXTI (External Interrupts)** pentru un răspuns mai rapid și mai precis.

Având în vedere că întreruperea de timer se execută la fiecare secundă, este necesar să obții un răspuns instantaneu de la buton, ceea ce nu poate fi realizat printr-un mecanism simplu de polling.

Sistemul bazat pe întreruperi funcționează corect, aproape fără întârziere, oferind un răspuns instantaneu atunci când butonul este apăsat.


# Erori intampinate
![image](https://github.com/user-attachments/assets/f71b1efb-61ad-43fa-81b4-325703f7d0d7)

## Erori cauzate de ST-LINK
În timpul inițializării serverului ST-LINK, poate apărea următoarea eroare:

```plaintext
Starting server with the following options:
        Persistent Mode            : Disabled
        Logging Level              : 1
        Listen Port Number         : 61234
        Status Refresh Delay       : 15s
        Verbose Mode               : Disabled
        SWD Debug                  : Enabled
        InitWhile                  : Enabled

Target no device found

Error in initializing ST-LINK device.
Reason: No device found on target.
```
![image](https://github.com/user-attachments/assets/10c665b9-fd88-45b3-940c-50f6b17db397)

# Rezolvare problemă: Eroare la descărcarea firmware-ului STM32F4

### Problema
Când încerc să descarc și să instalez pachetul de firmware pentru STM32F4 din **STM32CubeIDE**, primesc următoarea eroare:

![image](https://github.com/user-attachments/assets/a3c80ec4-156b-4551-a355-b1d6ecea0539)


---

### Soluție

#### **1. Descărcare manuală a pachetului de firmware**
1. Accesezam [pagina oficială STM32CubeF4](https://www.st.com/en/embedded-software/stm32cubef4.html).
2. Descarcăm manual ultima versiune a pachetului de firmware (de exemplu, **STM32CubeF4 v1.28.1**).
3. După descărcare, extragem conținutul arhivei într-un folder local pe calculatorul tău.

---

#### **2. Instalare manuală în STM32CubeIDE**
1. Deschidem **STM32CubeIDE**.
2. Navigam la:  
   **Help > Manage Embedded Software Packages**.
3. Apasăm pe butonul **From Local...** (în partea de jos a ferestrei).
4. Selecteaza folderul unde ai extras pachetul de firmware descărcat manual.
5. Apasă **OK** pentru a instala pachetul.

---

#### **3. Schimbăm locația folderului de firmware (opțional)**
Dacă problema persistă:
1. Navigheazam la:  
   **Window > Preferences > STM32Cube > Firmware Repository**.
2. Schimbăm locația implicită a folderului pentru firmware, de exemplu:  C:\STM32Cube\Repository


---

#### **4. Verificare**
1. Repornește **STM32CubeIDE**.
2. Navighează din nou la:  
**Help > Manage Embedded Software Packages**.
3. Confirmă că pachetul STM32F4 apare ca instalat.

---

### Concluzie
Această soluție rezolvă problema descărcării automate și permite instalarea manuală a firmware-ului necesar pentru STM32F4 în STM32CubeIDE.


# Rezolvare problemă: Error finishing flash operation

### Problema2
Când încerc să încarc proiectul pe STM32 din **STM32CubeIDE**, primesc următoarea eroare:

![altaeroarepng](https://github.com/user-attachments/assets/c89cc5c6-5855-43c6-88d3-98d48b03901e)


---

### Soluții

#### **1. Verificăm conexiunea hardware**
1. Ne asigurăm că placa STM32 este conectată corect prin USB și că LED-ul de alimentare (**LD1**) este aprins.
2. Dacă folosim un **ST-Link extern**, verificăm următoarele conexiuni:
   - **SWDIO (PA13)** → conectat la **SWDIO (ST-Link)**.
   - **SWCLK (PA14)** → conectat la **SWCLK (ST-Link)**.
   - **GND** → conectat la **GND (ST-Link)**.

---

#### **2. Activăm opțiunea "Connect Under Reset"**
1. În **STM32CubeIDE**, mergem la **Run > Debug Configurations**.
2. Selectăm configurația proiectului.
3. În secțiunea **Debugger**:
   - Setăm **Reset Mode** pe **Connect Under Reset**.
   - Reducem frecvența SWD la **100 kHz**.
4. Salvăm și încercăm din nou să rulăm.

---

#### **3. Ștergem memoria microcontrollerului**
1. Deschidem **STM32CubeProgrammer**.
2. Ne conectăm la placa STM32 și apăsăm **Full Chip Erase** pentru a șterge memoria.
3. Încercăm din nou să încărcăm proiectul din STM32CubeIDE.

---

#### **4. Verificăm fișierul `.elf`**
1. Ne asigurăm că proiectul este compilat corect:
   - Apăsăm **Project > Build All** (sau `Ctrl + B`).
2. Verificăm dacă fișierul `.elf` se află în folderul `Debug` sau `Release` al proiectului.

---
#### **5. Verificăm firmware-ul ST-Link**
1. Actualizăm firmware-ul ST-Link utilizând [ST-Link Firmware Upgrade](https://www.st.com/en/development-tools/stsw-link007.html).
2. După actualizare, încercăm din nou să încărcăm proiectul.

---



### Concluzie
Aceste soluții abordează problema de conectare și eroarea **Error finishing flash operation**, asigurându-ne că fișierul `.elf` este corect încărcat pe microcontroller.


# Rezolvare probleme: No ST-LINK detected

### Problema
Când încercăm să pornim sesiunea de debug în **STM32CubeIDE**, primim următoarea eroare:

![image (1)](https://github.com/user-attachments/assets/17a63f0a-42ec-4851-a134-48069a99af54)


---


---

### Soluții

#### **1. Verificăm conexiunea ST-LINK**
1. Ne asigurăm că placa STM32 este conectată la calculator prin cablul USB.
2. Verificăm că LED-ul **LD1** de pe placă este aprins (indică alimentarea).
3. Dacă folosim un **ST-Link extern**, verificăm că toate conexiunile sunt corect realizate:
   - **SWDIO (PA13)** → conectat la **SWDIO (ST-Link)**.
   - **SWCLK (PA14)** → conectat la **SWCLK (ST-Link)**.
   - **GND** → conectat la **GND (ST-Link)**.
   - **3.3V (opțional)** → conectat la **3.3V (ST-Link)**.

---

#### **2. Reinstalăm driver-ul ST-LINK**
1. Descărcăm driver-ul ST-LINK de pe [STMicroelectronics](https://www.st.com/en/development-tools/stsw-link009.html).
2. Instalăm driver-ul și reconectăm placa la calculator.
3. Verificăm în **Device Manager** (Windows) că dispozitivul **STMicroelectronics ST-LINK** apare în secțiunea **Universal Serial Bus devices**.

---

#### **3. Actualizăm firmware-ul ST-LINK**
1. Descărcăm utilitarul **ST-Link Firmware Upgrade Tool** de pe [STMicroelectronics](https://www.st.com/en/development-tools/stsw-link007.html).
2. Conectăm placa și rulăm utilitarul pentru a actualiza firmware-ul ST-LINK.
3. După actualizare, încercăm din nou să pornim sesiunea de debug.

---

#### **4. Schimbăm configurația de debug în STM32CubeIDE**
1. Mergem la **Run > Debug Configurations**.
2. Selectăm configurația proiectului și verificăm următoarele setări:
   - **Debugger**: ST-LINK.
   - **Reset Mode**: Activăm **Connect Under Reset**.
   - **Interface**: Asigurăm că este setat pe **SWD**.
   - **Frequency**: Reducem frecvența SWD la **100 kHz**.
3. Salvăm și încercăm din nou să pornim debug-ul.

---
#### **5. Testăm conexiunea cu STM32CubeProgrammer**
1. Deschidem **STM32CubeProgrammer** și selectăm **ST-LINK** ca mod de conectare.
2. Încercăm să ne conectăm la microcontroller. Dacă conexiunea funcționează, problema este specifică STM32CubeIDE.
3. Dacă nici aici nu merge, folosim opțiunea **Full Chip Erase** pentru a reseta microcontrollerul.

---

### Concluzie
Aceste soluții ne ajută să rezolvăm problema de conectare la ST-LINK în **STM32CubeIDE**, fie prin actualizarea firmware-ului, fie prin verificarea conexiunilor și configurarea corectă a debugger-ului.


# Rezolvare probleme: Conexiune ST-LINK eșuată și cabluri USB incompatibile


---

### Soluții

#### **1. Verificăm conexiunea ST-LINK**
1. Ne asigurăm că placa STM32 este conectată la calculator prin cablul USB.
2. Verificăm că LED-ul **LD1** de pe placă este aprins (indică alimentarea).
3. Dacă folosim un **ST-Link extern**, verificăm că toate conexiunile sunt corect realizate:
   - **SWDIO (PA13)** → conectat la **SWDIO (ST-Link)**.
   - **SWCLK (PA14)** → conectat la **SWCLK (ST-Link)**.
   - **GND** → conectat la **GND (ST-Link)**.
   - **3.3V (opțional)** → conectat la **3.3V (ST-Link)**.

---

#### **2. Reinstalăm driver-ul ST-LINK**
1. Descărcăm driver-ul ST-LINK de pe [STMicroelectronics](https://www.st.com/en/development-tools/stsw-link009.html).
2. Instalăm driver-ul și reconectăm placa la calculator.
3. Verificăm în **Device Manager** (Windows) că dispozitivul **STMicroelectronics ST-LINK** apare în secțiunea **Universal Serial Bus devices**.

---

#### **3. Actualizăm firmware-ul ST-LINK**
1. Descărcăm utilitarul **ST-Link Firmware Upgrade Tool** de pe [STMicroelectronics](https://www.st.com/en/development-tools/stsw-link007.html).
2. Conectăm placa și rulăm utilitarul pentru a actualiza firmware-ul ST-LINK.
3. După actualizare, încercăm din nou să pornim sesiunea de debug.

---

#### **4. Schimbăm configurația de debug în STM32CubeIDE**
1. Mergem la **Run > Debug Configurations**.
2. Selectăm configurația proiectului și verificăm următoarele setări:
   - **Debugger**: ST-LINK.
   - **Reset Mode**: Activăm **Connect Under Reset**.
   - **Interface**: Asigurăm că este setat pe **SWD**.
   - **Frequency**: Reducem frecvența SWD la **100 kHz**.
3. Salvăm și încercăm din nou să pornim debug-ul.

---

#### **5. Testăm cablurile USB**
1. Am constatat că **unele cabluri USB funcționează doar pentru alimentare**, fără suport pentru transmiterea de date.
2. Am testat **3 cabluri diferite** până am găsit unul care suportă atât alimentare, cât și transfer de date.
3. Recomandăm utilizarea unui cablu de calitate, verificat anterior cu alte dispozitive.

---

#### **6. Testăm conexiunea cu STM32CubeProgrammer**
1. Deschidem **STM32CubeProgrammer** și selectăm **ST-LINK** ca mod de conectare.
2. Încercăm să ne conectăm la microcontroller. Dacă conexiunea funcționează, problema este specifică STM32CubeIDE.
3. Dacă nici aici nu merge, folosim opțiunea **Full Chip Erase** pentru a reseta microcontrollerul.

---

### Concluzie
Aceste soluții ne ajută să rezolvăm problema de conectare la ST-LINK în **STM32CubeIDE**, fie prin utilizarea unui cablu USB compatibil, fie prin actualizarea firmware-ului, verificarea conexiunilor și configurarea corectă a debugger-ului.












